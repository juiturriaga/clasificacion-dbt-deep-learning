# Reconstrucción de particiones BCS-DBT

Los dos archivos CSV incluidos son históricos, recuperados del proyecto. El cuaderno `01_seleccion_y_particion.ipynb` permite verificar los archivos y generar una propuesta de división por paciente del conjunto reservado.

**Advertencia:** `split_val_reconstruido.csv` y `split_test_reconstruido.csv` son nuevos y NO están identificados con las particiones originales que produjeron los resultados de la tesis. No sustituir los archivos históricos por estos sin comprobar su equivalencia.

## Ejecución

Requiere Python con `pandas`, `scikit-learn`, `jupyter` (o VS Code con extensión Jupyter). Abrir el notebook desde esta carpeta y ejecutar sus celdas en orden. En Colab, subir los CSV antes de ejecutarlo. No requiere descargar imágenes DICOM.
